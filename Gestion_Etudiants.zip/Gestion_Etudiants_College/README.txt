PROJET : GESTION DES INSCRIPTIONS ET DES NOTES - COLLÈGE

CONTENU DU DOSSIER
- main.py       : menu principal du programme
- Etudiants.py  : inscription des élèves dans Excel
- notes.py      : saisie des notes et calcul de la moyenne
- Etudiants.xlsx: classeur Excel avec les feuilles inscription, Notes et Guide

CLASSES DISPONIBLES
6ème, 5ème, 4ème et 3ème.

MATIÈRES
PC, Français, Anglais, Science, HG et CD-ROM. Les notes sont sur 20.
La moyenne est calculée automatiquement dans la colonne « Moyenne ».

COMMENT LANCER LE PROGRAMME
1. Extraire tout le ZIP dans un même dossier.
2. Installer Python si nécessaire.
3. Ouvrir un terminal dans ce dossier.
4. Installer la bibliothèque nécessaire avec :
   pip install openpyxl
5. Lancer le programme avec :
   python main.py

IMPORTANT
- Ne déplacez pas Etudiants.xlsx hors du dossier contenant les fichiers Python.
- Remplacez les noms et les notes d'exemple par vos vraies données.
- Fermez le fichier Excel dans Excel avant de sauvegarder des modifications depuis le programme.
